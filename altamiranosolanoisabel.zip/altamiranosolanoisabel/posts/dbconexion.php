<?php 
    $hn = 'localhost';
    $db = 'altamiranosisa';
    $un = 'root';
    $pw = '';
    $port = 3360;

?>
