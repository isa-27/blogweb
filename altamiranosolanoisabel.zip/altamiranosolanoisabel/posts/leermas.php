<?php
include("../blo.html");
include("bd.php");

echo $_GET["id"];
?>


<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        
        <link rel="stylesheet" href="../css/estilos.css">
         <style>

    



        </style>
</head>


<body>

<section>
    </section>
    <?php
    

    ?>
    
    </body>

</html>